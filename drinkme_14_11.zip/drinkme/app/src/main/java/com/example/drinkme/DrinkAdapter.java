package com.example.drinkme;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

class DrinkAdpter extends RecyclerView.Adapter<DrinkAdpter.MyViewHolder> {

    private final RecyclerViewInterface recyclerViewInterface;
    Context context;
    ArrayList<DrinksModel> drinksModels;

    public DrinkAdpter(Context context, ArrayList<DrinksModel> drinksModels, RecyclerViewInterface recyclerViewInterface){
        this.context = context;
        this.drinksModels = drinksModels;
        this.recyclerViewInterface = recyclerViewInterface;
    }

    @NonNull
    @Override
    public DrinkAdpter.MyViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        // Aqui é onde o layout é "inflado", onde adicionamos os dados
        LayoutInflater inflater = LayoutInflater.from(context);
        View view = inflater.inflate(R.layout.itens_list, parent, false);
        return new DrinkAdpter.MyViewHolder(view, recyclerViewInterface);
    }

    @Override
    public void onBindViewHolder(@NonNull DrinkAdpter.MyViewHolder holder, int position) {
        //designa os valores para as views, baseados na posição do Recycler view

        holder.tvName.setText(drinksModels.get(position).getDrinkName());
        holder.tvDescription.setText(drinksModels.get(position).getDrinkDescription());
        holder.tvPrice.setText(drinksModels.get(position).getDrinkPrice());
        holder.imageView.setImageResource(drinksModels.get(position).getDrinkImage());

    }

    @Override
    public int getItemCount() {
        // Indica a quantidade de itens que serão exibidos

        return drinksModels.size();
    }

    public static class MyViewHolder extends RecyclerView.ViewHolder {

        // Seleciona as views do projeto e trasforma em variáveis

        ImageView imageView;
        TextView tvName, tvDescription, tvPrice;


        public MyViewHolder(@NonNull View itemView, RecyclerViewInterface recyclerViewInterface) {
            super(itemView);

            imageView = itemView.findViewById(R.id.imageView);
            tvName = itemView.findViewById(R.id.drinkName);
            tvDescription = itemView.findViewById(R.id.drinkDescription);
            tvPrice = itemView.findViewById(R.id.drinkPrice);

            itemView.setOnClickListener(new View.OnClickListener() {
                @Override
                public void onClick(View v) {
                    if (recyclerViewInterface != null) {
                        int pos = getAdapterPosition();

                        if (pos != RecyclerView.NO_POSITION) {
                            recyclerViewInterface.onItemClick(pos);
                        }

                    }
                }
            });

        }
    }
}
