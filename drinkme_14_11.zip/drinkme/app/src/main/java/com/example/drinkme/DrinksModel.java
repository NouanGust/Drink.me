package com.example.drinkme;

class DrinksModel {
     String drinkName;
     String drinkDescription;
     String drinkPrice;
     int drinkImage;


     public DrinksModel(String drinkName, String drinkDescription, String drinkPrice, int drinkImage) {
          this.drinkName = drinkName;
          this.drinkDescription = drinkDescription;
          this.drinkPrice = drinkPrice;
          this.drinkImage = drinkImage;
     }

     public String getDrinkName() {
          return drinkName;
     }

     public String getDrinkDescription() {
          return drinkDescription;
     }

     public String getDrinkPrice() {
          return drinkPrice;
     }

     public int getDrinkImage() {
          return drinkImage;
     }
}
