package com.example.drinkme;

public interface RecyclerViewInterface {

    void onItemClick (int position);

}
