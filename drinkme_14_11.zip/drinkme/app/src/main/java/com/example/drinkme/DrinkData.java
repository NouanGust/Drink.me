package com.example.drinkme;

public class DrinkData {
    private String drinkName;
    private String drinkDescricao;
    private String preco;
    private Integer drinkImage;

    public DrinkData(String drinkName, String drinkDescricao, String preco, Integer drinkImage) {
        this.drinkName = drinkName;
        this.drinkDescricao = drinkDescricao;
        this.preco = preco;
        this.drinkImage = drinkImage;
    }

    public  String getDrinkName() {
        return drinkName;
    }

    public void setDrinkName(String drinkName) {
        this.drinkName = drinkName;
    }

    public String getDrinkDescricao() {
        return drinkDescricao;
    }

    public void setDrinkDescricao(String drinkDescricao) {
        this.drinkDescricao = drinkDescricao;
    }

    public String getPreco() {
        return preco;
    }

    public void setPreco(String preco) {
        this.preco = preco;
    }

    public Integer getDrinkImage() {
        return drinkImage;
    }

    public void setDrinkImage(Integer drinkImage) {
        this.drinkImage = drinkImage;
    }

    @Override
    public String toString() {
        return "DrinkData{" +
                "drinkName='" + drinkName + '\'' +
                ", drinkDescricao='" + drinkDescricao + '\'' +
                ", preco=" + preco +
                ", drinkImage=" + drinkImage +
                '}';
    }
}
