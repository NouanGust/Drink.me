package com.example.drinkme;

import android.content.Intent;
import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import java.util.ArrayList;

public class MainActivity extends AppCompatActivity implements RecyclerViewInterface{

    ArrayList<DrinksModel> drinksModel = new ArrayList<>();
    int [] drinksImages = {R.drawable.caipirinha, R.drawable.cosmopolitan, R.drawable.margarita, R.drawable.mojito};
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);

        setUpDrinkModels();

        DrinkAdpter adapter = new DrinkAdpter(this, drinksModel, this);
        recyclerView.setAdapter(adapter);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

    }

    private void setUpDrinkModels() {

        String[] drinksName = getResources().getStringArray(R.array.drink_name);
        String[] drinksDescription = getResources().getStringArray(R.array.drink_description);
        String[] drinksPrice = getResources().getStringArray(R.array.drink_price);

        for (int i = 0; i< drinksName.length; i++) {
            drinksModel.add(new DrinksModel(drinksName[i], drinksDescription[i], drinksPrice[i], drinksImages[i]));
        }

    }

    @Override
    public void onItemClick(int position) {
        Intent intent = new Intent(MainActivity.this, newActivity.class);
        intent.putExtra("NAME", drinksModel.get(position).getDrinkName());
        intent.putExtra("DESCRIPTION", drinksModel.get(position).getDrinkDescription());
        intent.putExtra("PRICE", drinksModel.get(position).getDrinkPrice());
        intent.putExtra("IMAGE", drinksModel.get(position).getDrinkImage());

        startActivity(intent);

    }
}
