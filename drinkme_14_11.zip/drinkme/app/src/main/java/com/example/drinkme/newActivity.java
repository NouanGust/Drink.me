package com.example.drinkme;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;
import android.widget.ImageView;
import android.widget.TextView;

public class newActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_new);

        String name = getIntent().getStringExtra("NAME");
        String description = getIntent().getStringExtra("DESCRIPTION");
        String price = getIntent().getStringExtra("PRICE");
        int image = getIntent().getIntExtra("IMAGE", 0);

        TextView titleTextView = findViewById(R.id.textViewTitle);
        TextView descTextView = findViewById(R.id.textViewDesc);
        ImageView imageView = findViewById(R.id.imageView2);

        titleTextView.setText(name);
        descTextView.setText(description);
        imageView.setImageResource(image);

    }
}