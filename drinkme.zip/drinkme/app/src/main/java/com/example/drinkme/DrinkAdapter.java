package com.example.drinkme;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;

public class DrinkAdapter  extends RecyclerView.Adapter<DrinkAdapter.ViewHolder> {

    DrinkData[] drinkData;
    Context context;

    public DrinkAdapter(DrinkData[] drinkData, MainActivity activity) {
        this.drinkData = drinkData;
        this.context = activity;
    }

    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {

        LayoutInflater layoutInflater = LayoutInflater.from(parent.getContext());
        View view = layoutInflater.inflate(R.layout.itens_list, parent, false);
        ViewHolder viewHolder = new ViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position) {
        final DrinkData drinkDataList = drinkData[position];
        holder.textViewDrinkName.setText(drinkDataList.getDrinkName());
        holder.textViewDrinkDescricao.setText(drinkDataList.getDrinkDescricao());
        holder.textViewDrinkPreco.setText(drinkDataList.getPreco());
        holder.drinkImage.setImageResource(drinkDataList.getDrinkImage());

        holder.itemView.setOnClickListener(new View.OnClickListener() {

            public void onClick(View v) {
                Toast.makeText(context, drinkDataList.getDrinkName(), Toast.LENGTH_SHORT).show();
            }
        });

    }



    @Override
    public int getItemCount() {
        return drinkData.length;
    }

    public class ViewHolder extends RecyclerView.ViewHolder{
        ImageView drinkImage;
        TextView textViewDrinkName;
        TextView textViewDrinkDescricao;
        TextView textViewDrinkPreco;

        public ViewHolder(@NonNull View itemView) {
            super(itemView);
            drinkImage = itemView.findViewById(R.id.imageView);
            textViewDrinkName = itemView.findViewById(R.id.drinkName);
            textViewDrinkDescricao = itemView.findViewById(R.id.drinkDeescricao);
            textViewDrinkPreco = itemView.findViewById(R.id.drinkPreco);

        }
    }
}
