package com.example.drinkme;

import android.os.Bundle;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

public class MainActivity extends AppCompatActivity {
    @Override
    protected void onCreate(@Nullable Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        RecyclerView recyclerView = findViewById(R.id.recyclerView);
        recyclerView.setHasFixedSize(true);
        recyclerView.setLayoutManager(new LinearLayoutManager(this));

        DrinkData[] drinkData = new DrinkData[] {
                new DrinkData("Mojito", "bebida a base de rum e hortelã", "21,90", R.drawable.mojito),
                new DrinkData("Caipirinha", "bebida a base de cachaça e limão", "19,90", R.drawable.caipirinha),
                new DrinkData("", "bebida a base de rum e hortelã", "19,90", R.drawable.mojito),
                new DrinkData("Mojito", "bebida a base de rum e hortelã", "19,90", R.drawable.mojito),
        };

        DrinkAdapter drinkAdapter = new DrinkAdapter(drinkData, MainActivity.this);
        recyclerView.setAdapter(drinkAdapter);
    }
}
